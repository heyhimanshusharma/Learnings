const int trigpin = 9;
const int echopin = 10;

const int gl= 2;
const int yl= 3;
const int rl= 4;

const int buzzer= 8;
void setup() {
  // put your setup code here, to run once:
  pinMode(trigpin, OUTPUT);
  pinMode(echopin, INPUT);

  pinMode(gl, OUTPUT);
  pinMode(yl, OUTPUT);
  pinMode(rl, OUTPUT);

  pinMode(buzzer, OUTPUT);
  
  Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(trigpin, LOW);
  delayMicroseconds(2);

  digitalWrite(trigpin, HIGH);
  delayMicroseconds(10);

  digitalWrite(trigpin, LOW);

  long duration = pulseIn(echopin, HIGH);

  float distance = duration / 58;
  
  Serial.print("Distance in cm: ");
  Serial.println(distance);

  Serial.print(duration/58);
  digitalWrite(gl, LOW);
  digitalWrite(yl, LOW);
  digitalWrite(rl, LOW);
  noTone(buzzer);

  if(distance>100){
    //safe distance
    digitalWrite(gl, HIGH);
  }

  else if(distance>50){
    digitalWrite(yl, HIGH);
    tone(buzzer, 800);
    delay(300);
    noTone(buzzer);
    delay(700);
  }

  else if (distance>20){
    //very close
    digitalWrite(rl, HIGH);
    tone(buzzer, 1000);
    delay(200);
    noTone(buzzer);
    delay(300);
    }

  else{
    digitalWrite(rl, HIGH);
    tone(buzzer, 1500);
    delay(100);
    noTone(buzzer);
    delay(100);
  }
}
