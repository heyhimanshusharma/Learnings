const int pirpin =2;
const int ledpin =13;
const int buzzerpin =8;
void setup() {
  // put your setup code here, to run once:
  pinMode(pirpin, INPUT);
  pinMode(ledpin, OUTPUT);
  pinMode(buzzerpin, OUTPUT);
  Serial.begin(9600);
}

void loop() {
  // put your main code here, to run repeatedly:
  int motion = digitalRead(pirpin);
  if (motion == HIGH)
  {
    Serial.println("Motion is Detected.");
    digitalWrite(ledpin, HIGH);
    delay(5000);
    digitalWrite(ledpin, LOW);
    noTone(buzzerpin);

    Serial.println("Alarm and LED is off.");
  }
}
