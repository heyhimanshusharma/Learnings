const int buttonpin =2;
const int buzzerpin =8;
void setup() {
  // put your setup code here, to run once:
  pinMode(buttonpin, INPUT_PULLUP);
  pinMode(buzzerpin, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  int buttonstate = digitalRead(buttonpin);

  if (buttonstate == LOW){
    tone(buzzerpin,1000);
  }
  else{
    noTone(buzzerpin);
  }
}